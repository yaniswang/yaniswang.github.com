sudo chmod +x ./air_2.6_linux.bin
sudo ./air_2.6_linux.bin
sudo gsettings set com.canonical.Unity.Panel systray-whitelist "['all']"
sudo chmod 777 /etc/hosts
sudo dpkg -i hostsplus.v0.9.3_a64.deb
sudo chmod 777 /opt/hostsPlus/share/ext/*
sudo cp /usr/share/applications/hostsplus.desktop ~/Desktop
sudo chmod 777 ~/Desktop/hostsplus.desktop
sudo cp /usr/share/applications/hostsplus.desktop ~/桌面
sudo chmod 777 ~/桌面/hostsplus.desktop
/opt/hostsPlus/bin/hostsPlus