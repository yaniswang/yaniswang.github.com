sudo chmod 777 /etc/hosts
hdiutil attach hostsplus.v0.9.3.dmg