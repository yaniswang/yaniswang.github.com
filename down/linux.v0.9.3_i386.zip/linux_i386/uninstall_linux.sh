rm -f ~/Desktop/hostsplus.desktop
rm -f ~/桌面/hostsplus.desktop
sudo dpkg -r hostsplus
# sudo dpkg -r adobeair